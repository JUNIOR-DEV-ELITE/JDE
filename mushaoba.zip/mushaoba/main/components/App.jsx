const App = () => {
    return React.createElement(React.Fragment, null,
        React.createElement(LoadingScreen),
        React.createElement(Header),
        React.createElement(Hero),
        React.createElement(Stats),
        React.createElement(Team),
        React.createElement(Skills),
        React.createElement(Projects),
        React.createElement(Contact),
        React.createElement(Footer),
        React.createElement(ScrollTop)
    );
};

