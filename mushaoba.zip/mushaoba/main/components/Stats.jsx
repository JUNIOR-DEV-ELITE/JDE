const { useState, useEffect, useRef } = React;

function StatItem({ number, label, delay = 0 }) {
    const [isVisible, setIsVisible] = useState(false);
    const [count, setCount] = useState(0);
    const ref = useRef(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting && !isVisible) {
                    setIsVisible(true);
                    animateNumber();
                }
            },
            { threshold: 0.5 }
        );

        if (ref.current) {
            observer.observe(ref.current);
        }

        return () => {
            if (ref.current) {
                observer.unobserve(ref.current);
            }
        };
    }, []);

    const animateNumber = () => {
        const target = parseInt(number.replace(/\D/g, ''));
        const suffix = number.replace(/\d/g, '');
        const duration = 2000;
        const steps = 60;
        const increment = target / steps;
        let current = 0;

        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                setCount(target);
                clearInterval(timer);
            } else {
                setCount(Math.floor(current));
            }
        }, duration / steps);
    };

    return (
        <div 
            ref={ref}
            className={`stat-item ${isVisible ? 'visible' : ''}`}
            style={{ animationDelay: `${delay}ms` }}
        >
            <span className="stat-number">{count}{number.replace(/\d/g, '')}</span>
            <span className="stat-label">{label}</span>
        </div>
    );
}

function Stats() {
    const stats = [
        { number: '2+', label: 'Years Experience' },
        { number: '15+', label: 'Completed Projects' },
        { number: '10+', label: 'Happy Clients' },
        { number: '100%', label: 'Client Satisfaction' }
    ];

    return (
        <section className="stats-section">
            <div className="container">
                <div className="stats-grid">
                    {stats.map((stat, index) => (
                        <StatItem 
                            key={index}
                            number={stat.number}
                            label={stat.label}
                            delay={index * 100}
                        />
                    ))}
                </div>
            </div>
        </section>
    );
}

