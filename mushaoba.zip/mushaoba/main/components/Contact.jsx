function Contact() {
    const contactInfo = [
        {
            icon: 'fas fa-phone',
            detail: '+995 599 50 63 36',
            subtext: 'Call or WhatsApp'
        },
        {
            icon: 'fas fa-envelope',
            detail: 'Nikolozbregvadze49@gmail.com',
            subtext: 'Email Response within 24h'
        }
    ];

    return (
        <section id="contact" className="contact-section">
            <div className="container">
                <h2 className="section-title">Contact Us</h2>
                <p className="section-subtitle">
                    Available for freelance projects and collaborations
                </p>
                <div className="contact-info">
                    {contactInfo.map((item, index) => (
                        <div key={index} className="contact-item">
                            <i className={`${item.icon} contact-icon`}></i>
                            <span className="contact-detail">{item.detail}</span>
                            <span className="contact-subtext">{item.subtext}</span>
                        </div>
                    ))}
                </div>
                <div className="contact-cta">
                    <a href="mailto:Nikolozbregvadze49@gmail.com" className="cta-button">
                        Send Us an Email
                    </a>
                </div>
            </div>
        </section>
    );
}

