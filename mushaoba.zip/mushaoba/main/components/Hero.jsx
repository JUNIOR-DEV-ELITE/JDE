function Hero() {
    return (
        <section className="hero">
            <div className="container">
                <div className="hero-content">
                    <h2>Development Team</h2>
                    <p>
                        We are a development team specializing in modern web technologies.
                        Our focus is on building clean, efficient, and scalable applications
                        using Python, React, and JavaScript.
                    </p>
                    <a href="#contact" className="cta-button">Start Your Project</a>
                </div>
            </div>
        </section>
    );
}

