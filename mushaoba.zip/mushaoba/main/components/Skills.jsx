function SkillCard({ icon, title, description }) {
    return (
        <div className="skill-card">
            <i className={`${icon} skill-icon`}></i>
            <h3>{title}</h3>
            <p>{description}</p>
        </div>
    );
}

function Skills() {
    const skills = [
        {
            icon: 'fab fa-python',
            title: 'Python Development',
            description: 'Building robust backends, RESTful APIs, and data processing applications with clean Python code.'
        },
        {
            icon: 'fab fa-react',
            title: 'React Frontend',
            description: 'Creating dynamic, responsive user interfaces with modern React for seamless user experiences.'
        },
        {
            icon: 'fab fa-js',
            title: 'JavaScript',
            description: 'Full JavaScript proficiency including modern ES6+ features and asynchronous programming.'
        }
    ];

    return (
        <section id="skills" className="skills-section">
            <div className="container">
                <h2 className="section-title">Technical Expertise</h2>
                <p className="section-subtitle">
                    Mastery of modern web development technologies
                </p>
                <div className="skills-grid">
                    {skills.map((skill, index) => (
                        <SkillCard key={index} {...skill} />
                    ))}
                </div>
            </div>
        </section>
    );
}

