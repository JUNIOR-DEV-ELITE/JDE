function Footer() {
    const currentYear = new Date().getFullYear();
    const socialLinks = [
        { icon: 'fab fa-github', href: '#' },
        { icon: 'fab fa-linkedin-in', href: '#' },
        { icon: 'fab fa-codepen', href: '#' }
    ];

    return (
        <footer>
            <div className="container">
                <div className="footer-logo">JDE</div>
                <div className="social-links">
                    {socialLinks.map((link, index) => (
                        <a 
                            key={index}
                            href={link.href} 
                            className="social-link"
                            aria-label="Social media link"
                        >
                            <i className={link.icon}></i>
                        </a>
                    ))}
                </div>
                <p className="copyright">
                    © {currentYear} Junior Development Team. All rights reserved.
                </p>
            </div>
        </footer>
    );
}

