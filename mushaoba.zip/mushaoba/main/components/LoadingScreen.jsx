const { useState, useEffect } = React;

function LoadingScreen() {
    const [progress, setProgress] = useState(0);
    const [isHidden, setIsHidden] = useState(false);

    useEffect(() => {
        let currentProgress = 0;
        const interval = setInterval(() => {
            currentProgress += Math.random() * 25;
            if (currentProgress > 100) currentProgress = 100;
            setProgress(currentProgress);
            
            if (currentProgress >= 100) {
                clearInterval(interval);
                setTimeout(() => {
                    setIsHidden(true);
                }, 300);
            }
        }, 100);

        return () => clearInterval(interval);
    }, []);

    return (
        <div className={`loading-screen ${isHidden ? 'hidden' : ''}`} id="loadingScreen">
            <div className="loading-content">
                <div className="loading-logo">JDE</div>
                <div className="loading-bar">
                    <div 
                        className="loading-progress" 
                        id="loadingProgress"
                        style={{ width: `${progress}%` }}
                    ></div>
                </div>
            </div>
        </div>
    );
}

