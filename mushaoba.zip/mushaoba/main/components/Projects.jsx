function Projects() {
    const projects = [
        {
            title: 'Featured Projects Showcase',
            description: 'Explore our premium client work including luxury fashion platforms and fitness applications.',
            tech: ['Luxury Design', 'Client Work', 'Premium Projects'],
            href: '#featured'
        },
        {
            title: 'E-Commerce Dashboard',
            description: 'Admin dashboard with real-time analytics, inventory tracking, and sales reporting.',
            tech: ['React', 'Python', 'SQLite']
        },
        {
            title: 'Task Management System',
            description: 'Collaborative application with real-time updates and progress tracking.',
            tech: ['JavaScript', 'HTML/CSS']
        }
    ];

    const featuredProjects = [
        {
            title: 'LUXE COUTURE',
            description: 'Premium luxury fashion e-commerce platform with elegant design and seamless user experience.',
            link: 'https://junior-dev-elite.github.io/LUXE-COUTURE/'
        },
        {
            title: 'LUXE Collection',
            description: 'Sophisticated luxury brand website with modern aesthetics and premium user interface.',
            link: 'https://junior-dev-elite.github.io/luxe/'
        },
        {
            title: 'LuxFit',
            description: 'Premium fitness and wellness platform with elegant design and smooth animations.',
            link: 'https://junior-dev-elite.github.io/LuxFit/'
        }
    ];

    return (
        <>
            <section id="projects" className="projects-section">
                <div className="container">
                    <h2 className="section-title">Recent Projects</h2>
                    <p className="section-subtitle">Showcase of our technical capabilities</p>
                    <div className="projects-grid">
                        {projects.map((project, index) => (
                            <a 
                                key={index}
                                href={project.href || '#'}
                                className="project-card"
                            >
                                <h3>{project.title}</h3>
                                <p>{project.description}</p>
                                <div className="project-tech">
                                    {project.tech.map((tech, techIndex) => (
                                        <span key={techIndex} className="tech-tag">{tech}</span>
                                    ))}
                                </div>
                            </a>
                        ))}
                    </div>
                </div>
            </section>

            <section id="featured" className="featured-projects">
                <div className="container">
                    <h2 className="section-title">Featured Client Work</h2>
                    <p className="section-subtitle">
                        Premium projects showcasing our luxury design expertise
                    </p>
                    <div className="featured-projects-grid">
                        {featuredProjects.map((project, index) => (
                            <div key={index} className="featured-project-card">
                                <div className="featured-project-content">
                                    <h3>{project.title}</h3>
                                    <p>{project.description}</p>
                                    <a 
                                        href={project.link} 
                                        className="project-link" 
                                        target="_blank"
                                        rel="noopener noreferrer"
                                    >
                                        <i className="fas fa-external-link-alt"></i> Visit Live Website
                                    </a>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </>
    );
}

