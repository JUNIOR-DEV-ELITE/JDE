const { useState, useEffect } = React;

function Header() {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };

        window.addEventListener('scroll', handleScroll, { passive: true });
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    const closeMenu = () => {
        setIsMenuOpen(false);
    };

    return (
        <header id="mainHeader" className={isScrolled ? 'scrolled' : ''}>
            <div className="container">
                <div className="header-content">
                    <div className="logo">
                        <div className="logo-icon">JDE</div>
                        <div className="logo-text">
                            <h1>JUNIORDEV</h1>
                        </div>
                    </div>

                    <button 
                        className="mobile-menu-btn" 
                        id="mobileMenuBtn"
                        onClick={toggleMenu}
                        aria-label="Toggle menu"
                    >
                        <i className={isMenuOpen ? "fas fa-times" : "fas fa-bars"}></i>
                    </button>

                    <nav id="mainNav" className={isMenuOpen ? 'active' : ''}>
                        <ul>
                            <li><a href="#team" onClick={closeMenu}>Team</a></li>
                            <li><a href="#skills" onClick={closeMenu}>Skills</a></li>
                            <li><a href="#projects" onClick={closeMenu}>Projects</a></li>
                            <li><a href="#contact" onClick={closeMenu}>Contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </header>
    );
}

