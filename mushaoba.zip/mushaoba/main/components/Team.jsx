function TeamMember({ name, projects, experience, description, skills }) {
    return (
        <div className="team-member">
            <div className="member-header">
                <h3 className="member-name">{name}</h3>
            </div>
            <div className="member-details">
                <div className="member-stats">
                    <div className="stat">
                        <span className="stat-value">{projects}</span>
                        <span className="stat-label">Projects</span>
                    </div>
                    <div className="stat">
                        <span className="stat-value">{experience}</span>
                        <span className="stat-label">Years Experience</span>
                    </div>
                </div>
                <p>{description}</p>
                <div className="skills-list">
                    {skills.map((skill, index) => (
                        <span key={index} className="skill-tag">{skill}</span>
                    ))}
                </div>
            </div>
        </div>
    );
}

function Team() {
    const teamMembers = [
        {
            name: 'Nikoloz Bregvadze',
            projects: '15+',
            experience: '2.5',
            description: 'Specializes in creating efficient, scalable web applications with clean code and modern best practices.',
            skills: ['Python', 'React', 'JavaScript', 'HTML/CSS']
        },
        {
            name: 'Giorgi Shengelia',
            projects: '8+',
            experience: '2',
            description: 'Focuses on clean, efficient, and well-documented code with attention to detail and optimal performance.',
            skills: ['Python', 'JavaScript', 'React', 'APIs']
        }
    ];

    return (
        <section id="team" className="team-section">
            <div className="container">
                <h2 className="section-title">Our Development Team</h2>
                <p className="section-subtitle">
                    A dedicated team focused on creating quality software solutions
                </p>
                <div className="team-members">
                    {teamMembers.map((member, index) => (
                        <TeamMember key={index} {...member} />
                    ))}
                </div>
            </div>
        </section>
    );
}

