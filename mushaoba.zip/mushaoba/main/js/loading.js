export function initLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    const loadingProgress = document.getElementById('loadingProgress');
    
    if (!loadingScreen || !loadingProgress) return;
    
    let progress = 0;
    const loadingInterval = setInterval(() => {
        progress += Math.random() * 25;
        if (progress > 100) progress = 100;
        loadingProgress.style.width = `${progress}%`;
        
        if (progress >= 100) {
            clearInterval(loadingInterval);
            setTimeout(() => {
                loadingScreen.classList.add('hidden');
            }, 300);
        }
    }, 100);
}

