// #region agent log
fetch('http://127.0.0.1:7242/ingest/6ba935cc-04ae-41a2-9412-65a110f777f4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'main.js:1',message:'main.js module loading started',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
// #endregion
try {
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/6ba935cc-04ae-41a2-9412-65a110f777f4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'main.js:4',message:'Attempting to import animations',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
    // #endregion
    const { initAnimations } = await import('./animations.js');
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/6ba935cc-04ae-41a2-9412-65a110f777f4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'main.js:7',message:'Animations imported successfully',data:{initAnimationsExists:!!initAnimations},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
    // #endregion
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/6ba935cc-04ae-41a2-9412-65a110f777f4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'main.js:9',message:'Attempting to import utils',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
    // #endregion
    const { initApp } = await import('./utils.js');
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/6ba935cc-04ae-41a2-9412-65a110f777f4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'main.js:12',message:'Utils imported successfully',data:{initAppExists:!!initApp},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
    // #endregion

    // Initialize modules (loading, navigation, scrollTop are now handled by React)
    // Only initialize animations and utilities
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/6ba935cc-04ae-41a2-9412-65a110f777f4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'main.js:17',message:'Calling initAnimations',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
    // #endregion
    initAnimations();
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/6ba935cc-04ae-41a2-9412-65a110f777f4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'main.js:19',message:'Calling initApp',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
    // #endregion
    initApp();
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/6ba935cc-04ae-41a2-9412-65a110f777f4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'main.js:21',message:'All modules initialized',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
    // #endregion
} catch (error) {
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/6ba935cc-04ae-41a2-9412-65a110f777f4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'main.js:23',message:'Module import/init error',data:{error:error.message,stack:error.stack?.substring(0,200)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
    // #endregion
    console.error('Module initialization error:', error);
}

