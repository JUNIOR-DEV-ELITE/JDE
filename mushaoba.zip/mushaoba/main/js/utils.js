export function updateCopyright() {
    const year = new Date().getFullYear();
    const copyright = document.querySelector('.copyright');
    if (copyright) {
        copyright.textContent = copyright.textContent.replace(/\d{4}/, year);
    }
}

export function initApp() {
    // Initialize all modules when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            updateCopyright();
        });
    } else {
        updateCopyright();
    }
}

